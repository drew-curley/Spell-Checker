# Gcirku Bible
